// import { createStore } from 'redux';
// import { increment, decrement } from './actions';
// import performAction from './reducers';

// const store = createStore(performAction);

// store.subscribe(() => console.log(store.getState()));

// // store.dispatch(increment());
// // store.dispatch(increment());
// // store.dispatch(increment());
// // store.dispatch(decrement());

// export default store;
